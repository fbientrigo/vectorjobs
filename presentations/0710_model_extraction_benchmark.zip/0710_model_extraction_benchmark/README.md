# Apolo — extracción laboral y benchmark de modelos

Presentación en español basada en el estilo de `presentations/0625_apolo.zip`.

## Archivos

- `main.tex`: deck Beamer.
- `figures/`: gráficos derivados para el deck.
- `build_assets.py`: regenera gráficos y CSVs derivados sin rerunear modelos.
- `source_summary.json`: resumen de fuentes locales usadas.
- `model_comparison_used.csv`: copia derivada del reporte usado.
- `benchmark_table_used.csv`: copia derivada del benchmark usado.

## Fuentes usadas

- `data/bronze/jobs.db`
- `data/silver/jobs.parquet`
- `data/silver/agent_labeling/`
- `reports/baseline_regex_v0_1.json`
- `experiments/apolo_job_extraction_model_eval_50/`
- `experiments/apolo_job_extraction_model_eval_50/reports/model_comparison.csv`
- `experiments/apolo_job_extraction_model_eval_50/reports/model_comparison.md`
- `experiments/apolo_job_extraction_model_eval_50/reports/model_comparison_ranked.md`
- `experiments/apolo_job_extraction_model_eval_50/reports/model_comparison_pareto.md`
- `experiments/apolo_job_extraction_model_eval_50/reports/benchmark_table.csv`
- `experiments/apolo_job_extraction_model_eval_50/reports/historical_baseline_comparison.csv`
- `experiments/apolo_job_extraction_model_eval_50/reports/historical_model_efficiency.csv`
- `experiments/apolo_job_extraction_model_eval_50/evaluation_protocol.md`
- `experiments/apolo_job_extraction_model_eval_50/gold/annotation_guidelines.md`
- model outputs under `experiments/apolo_job_extraction_model_eval_50/outputs/`

## Regenerar

Desde la raíz del repo:

```powershell
.\.venv\Scripts\python.exe presentations\0710_model_extraction_benchmark\build_assets.py
cd presentations\0710_model_extraction_benchmark
pdflatex -interaction=nonstopmode main.tex
pdflatex -interaction=nonstopmode main.tex
```

Si `pdflatex` no está disponible, usar `tectonic main.tex` desde este directorio.

## Notas

- No rerunear modelos externos.
- No modificar muestras congeladas.
- No sobrescribir outputs raw.
- `operational_candidate_score` es proxy operacional, no accuracy.
- La evaluación contra gold humano está pendiente: no existe `gold/human_gold_50.jsonl`.
