from __future__ import annotations

import json
import shutil
import sqlite3
from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd


ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
FIGS = HERE / "figures"
REPORTS = ROOT / "experiments" / "apolo_job_extraction_model_eval_50" / "reports"
EXP = ROOT / "experiments" / "apolo_job_extraction_model_eval_50"


COLORS = {
    "blue": "#1f4e79",
    "light_blue": "#5b9bd5",
    "orange": "#ed7d31",
    "gray": "#7f7f7f",
    "green": "#70ad47",
    "red": "#c00000",
    "dark": "#1f1f1f",
}


def short_model(name: str) -> str:
    return {
        "deepseek/deepseek-v4-flash": "DeepSeek v4 Flash",
        "deepseek/deepseek-v4-pro": "DeepSeek v4 Pro",
        "minimax/minimax-m3": "MiniMax M3",
        "xiaomi/mimo-v2.5": "MiMo v2.5",
        "z-ai/glm-5.2": "GLM 5.2",
        "Claude Sonnet 5": "Claude Sonnet 5",
        "GPT-5.5 High": "GPT-5.5 High",
    }.get(name, name)


def base_axis(ax):
    ax.spines[["top", "right"]].set_visible(False)
    ax.grid(axis="y", color="#d9e2ec", linewidth=0.8)
    ax.set_axisbelow(True)
    ax.tick_params(axis="both", labelsize=9)


def save(fig, name: str):
    fig.tight_layout()
    fig.savefig(FIGS / name, dpi=180, bbox_inches="tight")
    plt.close(fig)


def barh(df, value_col, title, xlabel, name, color_col=None):
    order = df.sort_values(value_col, ascending=True)
    colors = [COLORS["blue"] if bool(x) else COLORS["gray"] for x in order[color_col]] if color_col else COLORS["blue"]
    fig, ax = plt.subplots(figsize=(8.2, 4.6))
    ax.barh(order["label"], order[value_col], color=colors)
    ax.set_title(title, loc="left", fontsize=14, fontweight="bold")
    ax.set_xlabel(xlabel)
    base_axis(ax)
    save(fig, name)


def main() -> None:
    FIGS.mkdir(parents=True, exist_ok=True)

    comparison = pd.read_csv(REPORTS / "model_comparison.csv")
    comparison["label"] = comparison["model"].map(short_model)
    comparison["completion_rate"] = comparison["n_rows_completed"] / comparison["n_rows_requested"]
    comparison["jobs_per_minute"] = 60 / comparison["seconds_per_completed_row"]

    benchmark = pd.read_csv(REPORTS / "benchmark_table.csv")
    benchmark["label"] = benchmark["model"].map(short_model)
    benchmark["quality_proxy"] = benchmark["quality_quality_value"]
    benchmark["jobs_per_minute"] = benchmark["efficiency_completed_jobs_per_minute"]

    hist = pd.read_csv(REPORTS / "historical_baseline_comparison.csv")
    hist_eff = pd.read_csv(REPORTS / "historical_model_efficiency.csv")

    con = sqlite3.connect(ROOT / "data" / "bronze" / "jobs.db")
    tables = {
        name: con.execute(f"select count(*) from {name}").fetchone()[0]
        for (name,) in con.execute("select name from sqlite_master where type='table' order by name")
    }
    con.close()

    silver = pd.read_parquet(ROOT / "data" / "silver" / "jobs.parquet")
    baseline = json.loads((ROOT / "reports" / "baseline_regex_v0_1.json").read_text(encoding="utf-8"))
    sample_manifest = json.loads((EXP / "input" / "sample_manifest.json").read_text(encoding="utf-8"))
    gemini_manifest = json.loads(
        (ROOT / "data" / "silver" / "agent_labeling" / "job_level_apolo_extractions_all_manifest.json").read_text(
            encoding="utf-8"
        )
    )

    # Preserve existing benchmark SVGs under the requested deck-local figure folder.
    for src in (REPORTS / "figures").glob("*.svg"):
        shutil.copy2(src, FIGS / src.name)

    barh(
        comparison,
        "n_rows_completed",
        "Jobs válidos completados de 50 solicitados",
        "jobs válidos",
        "valid_completion_rate.png",
        "hard_gate_pass",
    )

    fail = comparison.assign(
        faltantes=lambda d: d["n_rows_requested"] - d["n_rows_completed"],
        parseo=lambda d: d["json_parse_failures"],
        evidencia=lambda d: d["evidence_substring_failures"],
        validacion=lambda d: d["validation_failure_count"],
    )
    fail = fail.sort_values("n_rows_completed", ascending=True)
    fig, ax = plt.subplots(figsize=(8.2, 4.6))
    left = [0] * len(fail)
    for col, color in [("faltantes", COLORS["gray"]), ("parseo", COLORS["orange"]), ("validacion", COLORS["red"]), ("evidencia", COLORS["blue"])]:
        ax.barh(fail["label"], fail[col], left=left, label=col, color=color)
        left = [a + b for a, b in zip(left, fail[col])]
    ax.set_title("Perfil de fallas estructurales", loc="left", fontsize=14, fontweight="bold")
    ax.set_xlabel("conteo sobre 50")
    ax.legend(ncol=4, frameon=False, fontsize=8)
    base_axis(ax)
    save(fig, "failure_profile.png")

    barh(comparison, "estimated_cost_usd", "Costo API-equivalente para 50 casos", "USD", "cost_50_cases.png")
    barh(comparison, "jobs_per_minute", "Velocidad estimada/medida", "jobs por minuto", "speed_jobs_per_minute.png")

    fig, ax = plt.subplots(figsize=(7.4, 4.6))
    colors = [COLORS["blue"] if x else COLORS["gray"] for x in comparison["hard_gate_pass"]]
    ax.scatter(comparison["estimated_cost_usd"], comparison["operational_candidate_score"], s=90, c=colors)
    for _, r in comparison.iterrows():
        ax.annotate(r["label"], (r["estimated_cost_usd"], r["operational_candidate_score"]), xytext=(5, 4), textcoords="offset points", fontsize=8)
    ax.set_title("Costo vs proxy operacional", loc="left", fontsize=14, fontweight="bold")
    ax.set_xlabel("USD por 50 casos")
    ax.set_ylabel("proxy operacional, no accuracy")
    base_axis(ax)
    save(fig, "cost_vs_quality_proxy.png")

    fig, ax = plt.subplots(figsize=(7.4, 4.6))
    size = 1200 * (comparison["estimated_cost_usd"] / comparison["estimated_cost_usd"].max()).clip(lower=0.06)
    ax.scatter(comparison["jobs_per_minute"], comparison["operational_candidate_score"], s=size, c=colors, alpha=0.72)
    for _, r in comparison.iterrows():
        ax.annotate(r["label"], (r["jobs_per_minute"], r["operational_candidate_score"]), xytext=(5, 4), textcoords="offset points", fontsize=8)
    ax.set_title("Velocidad vs proxy, burbuja = costo", loc="left", fontsize=14, fontweight="bold")
    ax.set_xlabel("jobs por minuto")
    ax.set_ylabel("proxy operacional, no accuracy")
    base_axis(ax)
    save(fig, "speed_quality_cost_bubble.png")

    gate = comparison[comparison["hard_gate_pass"]].copy()
    fig, ax = plt.subplots(figsize=(7.4, 4.6))
    ax.scatter(gate["cost_per_completed_row"], gate["operational_candidate_score"], s=100, c=COLORS["blue"])
    for _, r in gate.iterrows():
        ax.annotate(r["label"], (r["cost_per_completed_row"], r["operational_candidate_score"]), xytext=(5, 4), textcoords="offset points", fontsize=8)
    ax.set_title("Pareto costo-calidad operacional", loc="left", fontsize=14, fontweight="bold")
    ax.set_xlabel("USD por job válido")
    ax.set_ylabel("proxy operacional, no accuracy")
    base_axis(ax)
    save(fig, "pareto_cost_quality.png")

    diag = comparison[["label", "skills_per_job_mean", "broad_domain_skill_rate", "seniority_unknown_rate", "confidence_mean"]].copy()
    diag = diag.sort_values("skills_per_job_mean")
    fig, ax = plt.subplots(figsize=(8.2, 4.6))
    x = range(len(diag))
    ax.plot(x, diag["skills_per_job_mean"], marker="o", label="skills/job", color=COLORS["blue"])
    ax.plot(x, diag["broad_domain_skill_rate"] * 10, marker="o", label="domain rate x10", color=COLORS["orange"])
    ax.plot(x, diag["seniority_unknown_rate"] * 10, marker="o", label="seniority unknown x10", color=COLORS["gray"])
    ax.set_xticks(list(x))
    ax.set_xticklabels(diag["label"], rotation=28, ha="right")
    ax.set_title("Diagnósticos de extracción", loc="left", fontsize=14, fontweight="bold")
    ax.legend(frameon=False, fontsize=8)
    base_axis(ax)
    save(fig, "extraction_diagnostics.png")

    gemini_row = {
        "label": "Gemini hist.",
        "skills_per_job_mean": float(hist.loc[0, "skills_per_job_mean"]),
        "broad_domain_skill_rate": float(hist.loc[0, "broad_domain_skill_rate"]),
        "confidence_mean": float(hist.loc[0, "confidence_mean"]),
    }
    controlled = comparison[comparison["hard_gate_pass"]][["label", "skills_per_job_mean", "broad_domain_skill_rate", "confidence_mean"]]
    comp = pd.concat([controlled, pd.DataFrame([gemini_row])], ignore_index=True)
    fig, ax = plt.subplots(figsize=(8.2, 4.6))
    ax.bar(comp["label"], comp["skills_per_job_mean"], color=[COLORS["blue"]] * (len(comp) - 1) + [COLORS["orange"]])
    ax.set_title("Referencia Gemini histórica: comparable solo en intersección semántica", loc="left", fontsize=13, fontweight="bold")
    ax.set_ylabel("skills por job")
    ax.tick_params(axis="x", rotation=25)
    base_axis(ax)
    save(fig, "gemini_historical_reference.png")

    summary = {
        "jobs_db_tables": tables,
        "silver_rows": int(len(silver)),
        "silver_columns": list(silver.columns),
        "regex_jobs_with_skills": baseline["jobs_with_regex_skills"],
        "regex_jobs_with_skills_pct": baseline["jobs_with_regex_skills_pct"],
        "frozen_sample_size": sample_manifest["sample_size"],
        "frozen_filtered_rows": sample_manifest["n_filtered_rows"],
        "controlled_models": comparison["model"].tolist(),
        "gemini_historical_rows": gemini_manifest["n_rows"],
        "gemini_historical_overlap": int(hist.loc[0, "frozen_50_overlap"]),
        "gemini_estimated_cost_usd": float(hist_eff.loc[0, "estimated_cost_usd"]),
        "missing_metrics": [
            "human-gold accuracy/F1 pending: gold/human_gold_50.jsonl is absent",
            "Claude/GPT wall-clock is API-equivalent estimate, not the original subscription runtime",
            "Historical Gemini source prompt/model identity is not verified in-repo",
        ],
    }
    (HERE / "source_summary.json").write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")
    comparison.to_csv(HERE / "model_comparison_used.csv", index=False)
    benchmark.to_csv(HERE / "benchmark_table_used.csv", index=False)


if __name__ == "__main__":
    main()
