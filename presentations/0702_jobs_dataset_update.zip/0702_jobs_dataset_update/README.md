# Apolo dataset laboral — 02 julio

Deck Beamer basado en `presentations/0625_apolo.zip`.

## Rebuild

Desde la raíz del repo:

```powershell
.\.venv\Scripts\python.exe presentations\0702_jobs_dataset_update\generate_figures.py
cd presentations\0702_jobs_dataset_update
pdflatex main.tex
pdflatex main.tex
```

## Fuentes usadas

- `data/bronze/jobs.db`
- `data/silver/jobs.parquet`
- `data/silver/job_extraction_candidates.parquet`
- `data/silver/manifest.json`
- `data/silver/extraction_manifest.json`
- `data/silver/agent_labeling/job_level_apolo_extractions_all.jsonl`
- `data/silver/agent_labeling/job_level_apolo_extractions_all_manifest.json`
- `data/silver/agent_labeling/agent_labeling_prompt.md`
- `data/silver/agent_labeling/agent_labeling_schema.json`
- `scripts/llm_labeler.py`
- `scripts/run_pipeline.py`
- `scripts/README_dataset.md`
- `docs/specs/01_data_contract.md`
- `docs/specs/02_extraction_labeling.md`
- `reports/storage_projection/storage_projection_manifest.json`

## Artefactos generados

- `figures/skill_category_distribution.png`
- `figures/top_extracted_skills.png`
- `figures/education_requirement_frequency.png`
- `figures/seniority_distribution.png`
- `figures/missing_unknown_fields.png`
- `figures/current_file_sizes.png`
- `figures/estimated_storage_growth.png`
- `figures/estimated_api_equivalent_cost.png`
- `figures/metrics.json`

## Métricas pendientes

- Costo real de API: pendiente de medir; no hay logs de tokens/billing.
- Validación humana completa: pendiente de medir; los labels son weak labels.
- Precision/recall por campo: pendiente de medir; no hay gold set humano completo.
- Normalización estable de educación/taxonomía: pendiente de medir.
