#!/usr/bin/env python3
"""Generate reproducible figures for the 2026-07-02 jobs dataset update."""

from __future__ import annotations

import argparse
import json
import re
import sqlite3
import unicodedata
from collections import Counter
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd


ROOT = Path(__file__).resolve().parents[2]
DEFAULT_OUT = Path(__file__).resolve().parent / "figures"
EXTRACTIONS = ROOT / "data/silver/agent_labeling/job_level_apolo_extractions_all.jsonl"
EXTRACTIONS_MANIFEST = ROOT / "data/silver/agent_labeling/job_level_apolo_extractions_all_manifest.json"
BRONZE_DB = ROOT / "data/bronze/jobs.db"
SILVER_JOBS = ROOT / "data/silver/jobs.parquet"
CANDIDATES = ROOT / "data/silver/job_extraction_candidates.parquet"
STORAGE_MANIFEST = ROOT / "reports/storage_projection/storage_projection_manifest.json"

COLORS = ["#1f4e79", "#2f75b5", "#70ad47", "#ed7d31", "#a5a5a5", "#5b9bd5", "#ffc000"]


def load_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def normalize(text: str | None) -> str:
    value = (text or "").strip()
    return value if value else "unknown"


def fold(text: str) -> str:
    base = unicodedata.normalize("NFKD", text.casefold())
    return "".join(char for char in base if not unicodedata.combining(char))


def canonical_education(text: str) -> str:
    key = re.sub(r"[^a-z0-9]+", " ", fold(text)).strip()
    key = re.sub(r"\bcompleta\b", "", key).strip()
    mappings = [
        (r"^(ensenanza media|secundaria)$", "Enseñanza media"),
        (r"^psicolog(o|a|ia)$", "Psicología / Psicólogo"),
        (r"^auxiliar de farmacia$", "Auxiliar de Farmacia"),
        (r"^quimico farmaceutico$", "Químico Farmacéutico"),
        (r"^ingeniero civil$", "Ingeniero Civil"),
        (r"^ingeniero comercial$", "Ingeniero Comercial"),
        (r"^ingeniero constructor$", "Ingeniero Constructor"),
        (r"^ingeniero industrial$", "Ingeniero Industrial"),
        (r"^constructor civil$", "Constructor Civil"),
        (r"^trabajo social$", "Trabajo Social"),
        (r"^trabajador social$", "Trabajo Social"),
        (r"^asistente social$", "Trabajo Social"),
    ]
    for pattern, label in mappings:
        if re.match(pattern, key):
            return label
    return normalize(text)


def collect_extractions(path: Path) -> dict:
    skill_categories: Counter[str] = Counter()
    skills: Counter[str] = Counter()
    education: Counter[str] = Counter()
    seniority: Counter[str] = Counter()
    warnings: Counter[str] = Counter()
    missing: Counter[str] = Counter()
    confidence_total = 0.0
    confidence_n = 0
    rows = 0
    examples = {"education": [], "warnings": []}

    with path.open("r", encoding="utf-8") as handle:
        for line in handle:
            if not line.strip():
                continue
            rows += 1
            record = json.loads(line)
            extraction = record["apolo_extraction"]
            row_skills = extraction.get("skills") or []
            row_education = extraction.get("education_requirements") or []
            row_warnings = extraction.get("warnings") or []
            row_seniority = normalize(extraction.get("seniority"))

            seniority[row_seniority] += 1
            if not row_skills:
                missing["skills"] += 1
            if not row_education:
                missing["education"] += 1
            if row_seniority == "unknown":
                missing["seniority"] += 1
            if not row_warnings:
                missing["warnings"] += 1

            for skill in row_skills:
                skill_categories[normalize(skill.get("category"))] += 1
                skills[normalize(skill.get("normalized_name") or skill.get("name"))] += 1
                confidence = skill.get("confidence")
                if isinstance(confidence, (int, float)):
                    confidence_total += float(confidence)
                    confidence_n += 1

            for item in row_education:
                if isinstance(item, dict):
                    label = normalize(
                        item.get("normalized_name")
                        or item.get("name")
                        or item.get("requirement")
                        or item.get("evidence")
                    )
                    if len(examples["education"]) < 5:
                        examples["education"].append(normalize(item.get("evidence") or label))
                else:
                    label = normalize(str(item))
                    if len(examples["education"]) < 5:
                        examples["education"].append(label)
                education[canonical_education(label)] += 1

            for warning in row_warnings:
                warnings[normalize(str(warning))] += 1
                if len(examples["warnings"]) < 5:
                    examples["warnings"].append(normalize(str(warning)))

    return {
        "rows": rows,
        "skill_categories": skill_categories,
        "skills": skills,
        "education": education,
        "seniority": seniority,
        "warnings": warnings,
        "missing": missing,
        "mean_skill_confidence": confidence_total / confidence_n if confidence_n else None,
        "examples": examples,
    }


def bronze_counts(db_path: Path) -> dict:
    with sqlite3.connect(db_path) as con:
        return {
            "jobs": int(con.execute("select count(*) from jobs").fetchone()[0]),
            "job_observations": int(con.execute("select count(*) from job_observations").fetchone()[0]),
            "crawl_runs": int(con.execute("select count(*) from crawl_runs").fetchone()[0]),
        }


def sizes() -> dict:
    paths = {
        "jobs.db": BRONZE_DB,
        "jobs.parquet": SILVER_JOBS,
        "job_extraction_candidates.parquet": CANDIDATES,
        "job_level_apolo_extractions_all.jsonl": EXTRACTIONS,
    }
    return {name: path.stat().st_size for name, path in paths.items() if path.exists()}


def barh(counter: Counter[str], path: Path, title: str, xlabel: str, n: int = 12) -> None:
    rows = counter.most_common(n)
    labels = [label for label, _ in rows][::-1]
    values = [value for _, value in rows][::-1]
    fig, ax = plt.subplots(figsize=(10, 5.6))
    ax.barh(labels, values, color=COLORS[1])
    ax.set_title(title)
    ax.set_xlabel(xlabel)
    ax.grid(axis="x", alpha=0.25)
    for i, value in enumerate(values):
        ax.text(value, i, f" {value:,}", va="center", fontsize=8)
    fig.tight_layout()
    fig.savefig(path, dpi=160)
    plt.close(fig)


def bars(counter: Counter[str], path: Path, title: str, ylabel: str) -> None:
    rows = counter.most_common()
    labels = [label for label, _ in rows]
    values = [value for _, value in rows]
    fig, ax = plt.subplots(figsize=(10, 5.6))
    ax.bar(labels, values, color=COLORS[: len(labels)])
    ax.set_title(title)
    ax.set_ylabel(ylabel)
    ax.grid(axis="y", alpha=0.25)
    ax.tick_params(axis="x", rotation=30)
    for i, value in enumerate(values):
        ax.text(i, value, f"{value:,}", ha="center", va="bottom", fontsize=8)
    fig.tight_layout()
    fig.savefig(path, dpi=160)
    plt.close(fig)


def file_size_chart(size_map: dict[str, int], path: Path) -> None:
    labels = list(size_map)
    values = [size_map[label] / 1_000_000 for label in labels]
    fig, ax = plt.subplots(figsize=(10, 5.6))
    ax.barh(labels[::-1], values[::-1], color=COLORS[0])
    ax.set_title("Archivos actuales del dataset")
    ax.set_xlabel("MB")
    ax.grid(axis="x", alpha=0.25)
    for i, value in enumerate(values[::-1]):
        ax.text(value, i, f" {value:.1f} MB", va="center", fontsize=8)
    fig.tight_layout()
    fig.savefig(path, dpi=160)
    plt.close(fig)


def storage_chart(path: Path) -> dict:
    manifest = load_json(STORAGE_MANIFEST)
    anchors = manifest["anchors"]
    months = list(range(0, 37, 6))
    base_gb = (
        anchors["bronze_db_bytes"]
        + anchors["silver_artifact_bytes"]
        + anchors["gold_bundle_bytes"]
        + EXTRACTIONS.stat().st_size
    ) / 1_000_000_000
    growths = {"0%/mes": 0.00, "5%/mes": 0.05, "12%/mes": 0.12}
    fig, ax = plt.subplots(figsize=(10, 5.6))
    for label, growth in growths.items():
        values = [base_gb * (1 + growth) ** month for month in months]
        ax.plot(months, values, marker="o", linewidth=2, label=label)
    ax.set_title("Crecimiento estimado de almacenamiento")
    ax.set_xlabel("Meses desde el corte")
    ax.set_ylabel("GB acumulados")
    ax.grid(alpha=0.25)
    ax.legend()
    ax.text(0.01, 0.01, "Base = archivos medidos; escenarios parametricos.", transform=ax.transAxes, fontsize=8, color="gray")
    fig.tight_layout()
    fig.savefig(path, dpi=160)
    plt.close(fig)
    return {"base_gb": base_gb, "scenarios": growths}


def api_cost_chart(path: Path, rows: int, avg_chars: float) -> dict:
    sizes = [rows, 100_000, 250_000, 500_000, 1_000_000]
    # ponytail: parametric API-equivalent model; replace with provider billing logs when available.
    usd_per_million_tokens = {"bajo": 0.15, "medio": 0.60, "alto": 2.50}
    tokens_per_job = max(avg_chars / 4.0, 1.0)
    fig, ax = plt.subplots(figsize=(10, 5.6))
    for label, rate in usd_per_million_tokens.items():
        costs = [n * tokens_per_job / 1_000_000 * rate for n in sizes]
        ax.plot(sizes, costs, marker="o", linewidth=2, label=f"{label}: ${rate}/M tok")
    ax.set_title("Costo API-equivalente por tamano de dataset")
    ax.set_xlabel("Postings procesados")
    ax.set_ylabel("USD por corrida")
    ax.grid(alpha=0.25)
    ax.legend(title="Escenario unitario")
    ax.text(0.01, 0.01, "No es gasto real: faltan logs de tokens/billing.", transform=ax.transAxes, fontsize=8, color="gray")
    fig.tight_layout()
    fig.savefig(path, dpi=160)
    plt.close(fig)
    return {"tokens_per_job_estimate": tokens_per_job, "usd_per_million_tokens": usd_per_million_tokens}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out-dir", type=Path, default=DEFAULT_OUT)
    args = parser.parse_args()
    args.out_dir.mkdir(parents=True, exist_ok=True)

    extracted = collect_extractions(EXTRACTIONS)
    manifest = load_json(EXTRACTIONS_MANIFEST)
    size_map = sizes()
    avg_jsonl_chars = EXTRACTIONS.stat().st_size / max(extracted["rows"], 1)

    barh(extracted["skill_categories"], args.out_dir / "skill_category_distribution.png", "Distribucion de categorias de skills", "Skills extraidas")
    barh(extracted["skills"], args.out_dir / "top_extracted_skills.png", "Top skills extraidas", "Menciones")
    barh(extracted["education"], args.out_dir / "education_requirement_frequency.png", "Requisitos educacionales frecuentes", "Menciones")
    bars(extracted["seniority"], args.out_dir / "seniority_distribution.png", "Distribucion de seniority", "Postings")
    bars(extracted["missing"], args.out_dir / "missing_unknown_fields.png", "Campos faltantes o unknown", "Postings")
    file_size_chart(size_map, args.out_dir / "current_file_sizes.png")
    storage = storage_chart(args.out_dir / "estimated_storage_growth.png")
    api_cost = api_cost_chart(args.out_dir / "estimated_api_equivalent_cost.png", extracted["rows"], avg_jsonl_chars)

    metrics = {
        "bronze": bronze_counts(BRONZE_DB),
        "manifest": manifest,
        "derived": {
            "rows_read": extracted["rows"],
            "top_skill_categories": extracted["skill_categories"].most_common(10),
            "top_skills": extracted["skills"].most_common(20),
            "top_education": extracted["education"].most_common(20),
            "seniority": extracted["seniority"],
            "warnings": extracted["warnings"],
            "missing": extracted["missing"],
            "mean_skill_confidence": extracted["mean_skill_confidence"],
            "examples": extracted["examples"],
            "file_sizes_bytes": size_map,
            "avg_jsonl_chars_per_job": avg_jsonl_chars,
            "storage_projection": storage,
            "api_equivalent_cost": api_cost,
        },
        "missing_metrics": [
            "Costo real de API: pendiente de medir; no hay logs de tokens/billing en los artefactos.",
            "Validacion humana de labels: pendiente de medir; el manifest declara weak labels.",
            "Precision/recall por campo: pendiente de medir; no hay gold set humano completo.",
        ],
    }
    (args.out_dir / "metrics.json").write_text(json.dumps(metrics, ensure_ascii=False, indent=2, default=dict), encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
